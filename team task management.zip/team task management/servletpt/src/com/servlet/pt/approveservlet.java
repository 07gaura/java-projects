package com.servlet.pt;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tech.blog.helper.ConnectionProvider;

/**
 * Servlet implementation class approveservlet
 */
@WebServlet("/approveservlet")
public class approveservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public approveservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<html><body>");
			String no = request.getParameter("id");
			int id = Integer.parseInt(no);
			int val=1;
			Connection connection2 = ConnectionProvider.getConnection();
	  		Statement statement2 = connection2.createStatement();
	  		String sql2 = "update task set status =? where id=?";
	  		PreparedStatement ptmt = connection2.prepareStatement(sql2);
			ptmt.setInt(1, val);
			ptmt.setInt(2, id);
			ptmt.executeUpdate();
			response.sendRedirect("profile.jsp");
			out.println("</html></body>");
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
