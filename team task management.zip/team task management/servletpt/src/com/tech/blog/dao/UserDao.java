package com.tech.blog.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.tech.blog.entities.User;

public class UserDao {
	private Connection con;

	public UserDao(Connection con) {
		super();
		this.con = con;
	}
	
	public boolean saveUser(User user) {
		boolean val = true;
		try {
			String query = "insert into user(name, email, password) values(?, ?, ?)";
			PreparedStatement ptmt =  this.con.prepareStatement(query);
			ptmt.setString(1, user.getName());
			ptmt.setString(2,user.getEmail());
			ptmt.setString(3, user.getPassword());
			
			ptmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return val;
	}
	
	public User getlogin(String email, String password) {
		User user = null;
		try {
			String query = "select * from user where email=? and password=?";
			PreparedStatement ptmt = con.prepareStatement(query);
			ptmt.setString(1,email);
			ptmt.setString(2, password);
			ResultSet set = ptmt.executeQuery();
			
			if(set.next()) {
				user = new User();
				int id = set.getInt("id");
				String name = set.getString("name");
				String emails = set.getString("email");
				String passwords = set.getString("password");
				
				user.setId(id);
				user.setName(name);
				user.setEmail(emails);
				user.setPassword(passwords);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return user;
	}
}
