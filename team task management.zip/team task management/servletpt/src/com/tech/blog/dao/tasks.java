package com.tech.blog.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.tech.blog.entities.task;

public class tasks {
	private Connection con;
	
	public tasks(Connection con) {
		this.con = con;
	}
	

	public boolean saveTask(task taskdes) {
		boolean val = true;
		try {
			String sql = "insert into task(taskdes,user) values(?, ?)";
			PreparedStatement ptmt = this.con.prepareStatement(sql);
			ptmt.setString(1, taskdes.getTaskdesc());
			ptmt.setInt(2, taskdes.getUser());

			ptmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return val;
	}
	
	
}
