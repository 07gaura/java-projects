package com.tech.blog.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.tech.blog.entities.taskuser;

public class taskuserDao {
	private Connection con;

	public taskuserDao(Connection con) {
		super();
		this.con = con;
	}
	public boolean saveTaskUser(taskuser user) {
		boolean val = true;
		try {
			String sql = "insert into taskuser(name, email, password) values(?,?,?)";
			PreparedStatement ptmt = this.con.prepareStatement(sql);
			ptmt.setString(1, user.getName());
			ptmt.setString(2, user.getEmail());
			ptmt.setString(3, user.getPassword());
			
			ptmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();			
		}
		return val;
	}
	
	public taskuser getLogin(String email, String password) {
		taskuser user = null;
		try {
			String sql = "select * from taskuser where email=? and password=?";
			PreparedStatement ptmt = con.prepareStatement(sql);
			ptmt.setString(1, email);
			ptmt.setString(2, password);
			ResultSet set = ptmt.executeQuery();
			
			if(set.next()) {
				user = new taskuser();
				String name = set.getString("name");
				String userpassword = set.getString("name");
				String useremail = set.getString("email");
				int id = set.getInt("id");
				
				user.setId(id);
				user.setEmail(useremail);
				user.setName(name);
				user.setPassword(userpassword);
				}			
			}
		catch(Exception e) {
			e.printStackTrace();
		}
		return user;
	}
}
