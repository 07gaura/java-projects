package com.tech.blog.entities;

public class task {
	public int id;
	public String taskdesc;
	public int user;
	public int status;
	
	public task() {
		super();
	}

	public task(int id, String taskdesc, int user) {
		super();
		this.id = id;
		this.taskdesc = taskdesc;
		this.user = user;
	}
	
	

	public task(String taskdesc, int user) {
		super();
		this.taskdesc = taskdesc;
		this.user = user;
	}

	public task(String taskdesc, int user, int status) {
		super();
		this.taskdesc = taskdesc;
		this.user = user;
		this.status = status;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTaskdesc() {
		return taskdesc;
	}

	public void setTaskdesc(String taskdesc) {
		this.taskdesc = taskdesc;
	}

	public int getUser() {
		return user;
	}

	public void setUser(int user) {
		this.user = user;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
	
}
